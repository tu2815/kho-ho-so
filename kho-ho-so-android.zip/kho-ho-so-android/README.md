# Kho hồ sơ: đóng gói APK

## Cách 1: build tự động trên GitHub (không cần cài gì)
1. Tạo repo GitHub mới, tải toàn bộ thư mục này lên (nhánh main).
2. Vào tab Actions, chạy "Build APK" (hoặc chờ tự chạy sau khi push).
3. Khi xong, mở lần chạy đó, tải mục Artifacts có tên kho-ho-so-apk, giải nén ra app-debug.apk.
4. Chép file về điện thoại Android, mở và cho phép cài từ nguồn không xác định.

## Cách 2: build trên máy tính (cần Node 18+, JDK 17, Android Studio)
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
APK nằm ở android/app/build/outputs/apk/debug/app-debug.apk

## Ghi chú
- Giao diện nằm ở www/index.html. Sửa xong chạy lại build.
- Đọc tệp PDF/DOCX cần có mạng lần đầu (tải thư viện đọc tệp).
- Đây là bản debug để dùng nội bộ. Muốn đưa lên Google Play cần ký bản release.
